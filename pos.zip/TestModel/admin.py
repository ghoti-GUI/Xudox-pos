from django.contrib import admin

# from .models import product

# admin.site.register(product)
