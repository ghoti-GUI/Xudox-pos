from django.contrib import admin
from .models import TestImg

# Register your models here.

admin.site.register(TestImg)